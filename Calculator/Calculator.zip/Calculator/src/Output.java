class Output extends Calculator { //Вывод это сообщения экрана калькулятора

    void displayMessage(String message) {
        System.out.println(message);
    }
}
