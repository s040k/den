class CalculatorException extends Exception {
    CalculatorException(String message) {
        super(message);

    }
}
